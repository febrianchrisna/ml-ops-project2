import tensorflow as tf
import tensorflow_transform as tft

# Sanitized feature names without special characters or spaces
CATEGORICAL_FEATURES = {
    "Sex": 2,  # Male/Female
}

# Mapping from CSV column names to sanitized names
FEATURE_MAP = {
    "%Red Pixel": "red_pixel",
    "%Green pixel": "green_pixel",
    "%Blue pixel": "blue_pixel",
    "Hb": "hb",
    "Sex": "Sex",  # Keep this the same since it's already valid
    "Anaemic": "Anaemic"  # Keep label name the same
}

# Using sanitized feature names
NUMERICAL_FEATURES = [
    "red_pixel",
    "green_pixel",
    "blue_pixel",
    "hb",
]

LABEL_KEY = "Anaemic"  # Target label


def transformed_name(key):
    """
    Renames a feature key by appending '_xf' to it.

    Args:
        key (str): The original feature key.

    Returns:
        str: The transformed feature key with '_xf' appended to it.
    """
    return key + '_xf'


def convert_num_to_one_hot(label_tensor, num_labels=2):
    """
    Convert a label (0 or 1) into a one-hot vector
    Args:
        int: label_tensor (0 or 1)
    Returns
        label tensor
    """
    one_hot_tensor = tf.one_hot(label_tensor, num_labels)
    return tf.reshape(one_hot_tensor, [-1, num_labels])


def preprocessing_fn(inputs):
    """
    Preprocesses the input data by applying transformations to categorical and numerical features.

    Args:
        inputs (dict): A dictionary containing the input data. The keys are 
        the feature names and the values are the corresponding feature values.

    Returns:
        dict: A dictionary containing the preprocessed data. The keys are the transformed 
        feature names and the values are the transformed feature values.
    """
    outputs = {}
    
    # Create a copy of inputs with sanitized feature names
    sanitized_inputs = {}
    for original_name, sanitized_name in FEATURE_MAP.items():
        if original_name in inputs:
            sanitized_inputs[sanitized_name] = inputs[original_name]
        
    # Process categorical features
    for key, dim in CATEGORICAL_FEATURES.items():
        sanitized_key = FEATURE_MAP.get(key, key)
        int_value = tft.compute_and_apply_vocabulary(
            sanitized_inputs[sanitized_key], top_k=dim + 1
        )
        outputs[transformed_name(sanitized_key)] = convert_num_to_one_hot(
            int_value, num_labels=dim + 1
        )

    # Process numerical features
    for feature in NUMERICAL_FEATURES:
        outputs[transformed_name(feature)] = tft.scale_to_0_1(sanitized_inputs[feature])

    # Convert Yes/No values to integers (Yes=1, No=0)
    sanitized_label = FEATURE_MAP.get(LABEL_KEY, LABEL_KEY)
    outputs[transformed_name(sanitized_label)] = tf.cast(
        tf.where(
            tf.equal(sanitized_inputs[sanitized_label], "Yes"),
            tf.constant(1, tf.int64),
            tf.constant(0, tf.int64)
        ),
        tf.int64
    )

    return outputs